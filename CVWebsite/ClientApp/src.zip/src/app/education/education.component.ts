import { Component } from '@angular/core';

@Component({
    selector: 'app-education',
    templateUrl: './education.component.html',
    styleUrls: ['./education.component.css']
})
/** education component*/
export class EducationComponent {
    /** education ctor */
    title1 = "Ph.D. Student, Computer Science ";
    date1 = "2016- Present";
    description1 = "The College of Computing & Informatics, Drexel University, Philadelphia, PA\nCurrent GPA: 3.88/4 \nAdvisor: Dr. Julia Stoyanovich";
    thesis1 ="";
    title2 = "M.S. Degree, Artificial Intelligence";
    date2 = "2013-2016";
    description2 = "The College of Computing & Informatics, Drexel University, Philadelphia, PA\nCurrent GPA: 3.88/4 \nAdvisor: Dr. Julia Stoyanovich";
    thesis2 ="Thesis: User Experience Design for Android Mobile Applications, \n supervision of Dr. Mohammad Reza Kangavari";
    constructor() {

    }
}
